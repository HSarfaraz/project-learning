import graphql from './graphql';

export default {
  graphql
};