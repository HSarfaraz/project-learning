module.exports = [{
      plugin: require('../gatsby-browser.js'),
      options: {"plugins":[]},
    }]
