module.exports = {
  
  plugins: [
    'gatsby-plugin-sass'
  ]

}
