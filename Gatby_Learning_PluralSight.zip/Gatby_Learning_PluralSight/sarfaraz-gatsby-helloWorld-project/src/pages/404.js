import React from "react"
import { Link } from "gatsby"
//import styles from './404.module.css';
import styles from './404.module.scss';
import Layout from '../components/layout';

export default ()=> (
   <Layout>
        <div className={styles.content}>
            <h1 className={styles.header}>Page Doesnot exists</h1>
            <p className={styles.errorMessage}>The page you are looking doesnot exist</p>
            <Link to="/">Home</Link>
        </div>
    </Layout>
)
