import React from 'react'
import styles from './layout.module.scss'

// Function Component
export default ({children}) => (
    <div className={styles.container}>
        {children}
    </div>
)