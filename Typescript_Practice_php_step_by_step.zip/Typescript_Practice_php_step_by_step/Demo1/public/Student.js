"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Login = /** @class */ (function () {
    function Login() {
        this.data = 'Student Login done';
    }
    return Login;
}());
exports.default = Login;
