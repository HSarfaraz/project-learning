"use strict";
// /// <reference path="./Utils.ts" />
// namespace UserUtils
// {
//     export class Users extends Parent{
//         getName(){
//             return this.name;
//         }
//     }
// }
Object.defineProperty(exports, "__esModule", { value: true });
// let a:number = 10.10;
// console.log(a);
// let data:string[]=['Sarfaraz','Priyanka','Deepika','Swheta'];
// data.push('Mishra');
// let data1:string[]=['Salman','Shahrukh','Aamir'];
// data1.push('Akshay');
// let data2:string[]=['Virat','Shreyas','Rahul'];
// data2.push('Rohit');
// let data3:string[]=['Katrina','Kareena','Kiara'];
// console.log(data3);
// console.log(data);
// Custom defined data type
// interface userTyped{
//     name:string,
//     age:number,
//     address:any
// }
// let users:any={
//     name:'Sarfaraz',
//     age:34,
//     address:true
// }
// users.name ='Priyanka';
// users.age = true;
// users.address = 'Indore'
// console.log(users);
// let data:string|number|boolean='Sarfaraz';
// data = 100;
// data = true;
// console.log(data);
// Interface
// interface userType{
//     name:string,
//     age:number,
//     city:string,
//     getName:()=> string
// }
// let users:userType={
//     name:'Sarfaraz',
//     age:34,
//     city:'Hyderabad',
//     getName : function(){
//         return this.name;
//     }
// }
// users.name='Cool Hussain';
// console.log(users.getName());
// function Cals(a:number,b?:number):number{
//     return b?a+b:a;
// }
// console.warn(Cals(100));
// function calulator(a:number,b?:number):number{
//     return b?a+b:a;
// }
// console.warn(calulator(100,500));
// FUnctions in class
// class App{
//     name:string="Hussain";
//     constructor(name){
//         this.name=name;
//     }
//     getName():string{
//         return this.name
//     }
// }
// let a = new App("Sarfaraz");
// console.log(a.getName());
// Inheritance
// class Parent{
//     name:string;
//     setName(name){
//         this.name=name;
//     }
// }
// class Child extends Parent{
//     getName(){
//         return this.name;
//     }
// }
// let c = new Child();
// c.setName("Sarfaraz");
// console.log(c.getName());
// import sLogin from './Student';
// import tLogin from './Teacher'
// let teacher = new tLogin();
// console.log(teacher.data);
// let student = new sLogin();
// console.log(student.data);
// Generics
// function users<T>(data:T):T{
//     return data
// }
// console.log(users({name:'sarfaraz',age:34}).age);
// enum
var Days;
(function (Days) {
    Days[Days["mon"] = 10] = "mon";
    Days[Days["tue"] = 11] = "tue";
    Days[Days["wed"] = 12] = "wed";
    Days[Days["thur"] = 13] = "thur";
    Days[Days["fri"] = 14] = "fri";
    Days[Days["sat"] = 15] = "sat";
    Days[Days["sun"] = 16] = "sun";
})(Days || (Days = {}));
//let whichDay:Days= Days.fri;
/*let whichDay:Days;
whichDay=Days.fri;*/
// function whichDay(day:Days){
//     return day
// }
// console.log(whichDay(Days.sun));
// Symbol:Primititive datatype, provide unique id
// let s1 = Symbol("d1");
// console.warn(s1);
// // let data={
// //     [s1]:'some data'
// // }
// // console.warn(data[s1]);
// class Demo{
//     demoF1(){
//         return "some data"
//     }
// }
// let d1 = new Demo();
// console.warn(d1.demoF1())
