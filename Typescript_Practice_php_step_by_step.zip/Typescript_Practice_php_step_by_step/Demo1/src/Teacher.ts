export default class Login{
    data='Teacher Login done';
}