export default class Login{
    data='Student Login done';
}